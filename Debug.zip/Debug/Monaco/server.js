const express = require('express');
const path = require('path');
const app = express();

// Serve folders with Monaco resources
app.use('/vs', express.static(path.join(__dirname, 'vs')));
app.use('/js', express.static(path.join(__dirname, 'js')));
app.use('/Fonts', express.static(path.join(__dirname, 'Fonts')));
app.use('/package', express.static(path.join(__dirname, 'package')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'monaco.html'));
});

app.listen(3000, () => console.log('Server running on http://localhost:3000'));